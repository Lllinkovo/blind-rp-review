# S2 专项报告：文献、缺口与可归属贡献

## 1. 专项结论与审核边界

**专项结论：所承诺的因果知识增量尚未获得所述比较的支持；文献缺口与新颖性为 UNKNOWN。** 本报告不发布整体 Verdict；因果识别缺陷是否构成整体 BLOCK，留待 S4 专项证据与 S5 裁决。

- 隔离状态：`INDEPENDENT_MODULES`；本角色从独立任务上下文开始，未接收父任务历史或其他专项判断。
- 边界执行：instruction-based，未宣称技术沙箱隔离。
- 体裁：189 词的虚构诊断摘录；按 S0 仅评所述因果主张及其贡献。无文献表、全文来源或项目约束，且未授权外查。因此不把缺少综述视作此摘录的拒稿理由。
- 实际读取：`examples/case-01/proposal.md`、`proposal.seal.json`、`S0_MANIFEST.md`、`S0_MANIFEST.seal.json`、`references/review-protocol.md`、`references/output-schema.md`、`references/modules/s2-literature-gap-contribution.md`。运行文件均位于 `runs/demo-2026-10-04-v1/`；未读取其他输入。
- 校验：仅执行 `scripts/seal_report.py` 的帮助和校验功能。proposal：1270 字节，SHA-256 `221A1DC6257DEF46A8E094D1BF9A0E6FE08474C3E8B86159D7008D9643430230`；S0：6880 字节，SHA-256 `095E4995CBFD52193FAA7C707B1BDAD1CB02223D4946F2C60B35550B047A4F0F`。两项均返回 `expected_match: true`。
- 边界违规：无已观察到的违规。封存校验只证明字节一致，不证明审核正确或模型之间无共同偏差。

## 2. 最强拒稿理由（限 S2 贡献范围）

P1 要求获得“distinct from differences between visitor groups”的导览形式因果效应；P2 的形式比较同时是两个不同访客群体、不同活动日的比较；P3 仅以组间检验显著性兑现因果贡献。这使“观察到两组分数不同”与“获得形式本身的因果知识”之间缺少支持环节。最强挽救是将成果限定为两个具体群体的描述性差异，但 P4 明确表示这不能回答中心问题。此处只指出贡献承诺与所述证据之间的断点，不另行开展方法或设计修复审核。

## 3. 专项 Gate table

| Gate | Result | 决定性证据 | 后果 |
|---|---|---|---|
| Field/literature home | UNKNOWN | P1–P4 均无文献定位 | 无法确认所属争论；不据此处罚诊断摘录 |
| Nearest-neighbour gap | UNKNOWN | P1 提出问题，但未列先行知识或检索界限 | 不能声称发现或消灭一个经核实的文献缺口 |
| Attributable contribution | MAJOR | P1 因果贡献；P2 两群体比较；P3 显著性解释；P4 描述性退路限制 | 贡献承诺尚未由所列证据支持，整体严重性待裁决 |
| 其他 Gate | 未评估 | 超出 S2 专项职责 | 不以 UNKNOWN 代替其他模块判断 |

### 论证图

先行知识 **UNKNOWN** → 既有研究局限 **UNKNOWN** → 未解问题（P1：音频相较文字是否增加次日事实记忆，**OBSERVED**）→ 提议比较（P2–P3：两种既有活动的群体均值检验，**OBSERVED**）→ 预期知识增量（P1、P3：导览形式的因果效应，**OBSERVED**）→ 贡献支持断点（比较结果不能自行排除群体差异这一解释，**INFERRED**）。

### 最近邻反驳与剩余缺口

最强待检验的最近邻，是已经比较相同内容音频与文字导览、并测量延迟事实记忆且能够区分受众差异的研究。若存在，它可能已经回答 P1；仅更换两场活动无法自动构成新增理论贡献。**这是一项反驳检验的目标类型，不是已核实存在的文献。** 无外查授权、无所引来源，故反驳结果为 UNKNOWN，不能虚构“已有研究证明”。

P1–P4 未声称新的机制、测量方法、理论矛盾或检索后的空白。可保留的是一个明确的因果问题；其是否构成剩余文献缺口未知。

### 贡献归属与结果方向检验

拟议前后知识变化可表述为：研究后将知道导览形式对次日事实记忆的因果效应，而非只知道两个访客群体的均值差异。所述资料至多直接支持后一个差异；把它归于导览形式仍需额外支持。

零结果或混合结果可以描述这两组的表现，但同样不能单凭检验结果回答形式的因果效应。因此问题不依赖结果是否显著，也不因使用更技术化措辞而消失。未发现贡献直接借用某一引文的证据；来源归属为 UNKNOWN。

## 4. Rejection-level finding

### F1 — 承诺的贡献超出比较所能直接归属的知识

- **Severity:** MAJOR（S2 局部；不作整体 BLOCK 裁决）
- **Module:** S2
- **Proposal evidence:** P1 “distinct from differences between visitor groups”；P2 “class receives audio guides”及“public-event group receives printed guides”；P3 “statistically significant difference will establish the causal effect”；P4 “descriptive difference … would not answer”。
- **Observed:** 核心贡献是形式的因果效应，证据来源是两个既有群体的比较，正文拒绝以描述性差异替代中心问题。
- **Failed condition:** 归属于形式的贡献需有证据将形式与群体差异区分；P1–P4 未提供该支持环节。
- **Consequence:** 即使获得显著差异，也未兑现 P1 所定义的知识增量；非显著结果同样不能兑现。
- **Strongest defence/fallback:** 同一文本内容降低了内容差异解释；局部描述性比较仍可能产生有关这两次活动的经验结果。
- **Residual problem:** 内容一致不等于受众可比；描述性结果受 P4 限制，不能直接充作中央贡献。是否存在保留中心的可信识别路径，应由 S4 审查；S2 不设计替代研究。
- **Detection confidence:** high
- **Severity confidence:** medium（贡献断点明确；整体不可挽救性需综合专项目块）
- **Decision test:** 出示能够支持“形式效应可与群体差异区分”的证据，并明确它怎样产生 P1 的知识增量；若只保留描述性结果，则需作者明确变更中心问题，而不能称原贡献已被支持。

## 5. 跨模块交接与反测

未读取其他报告，未进行跨模块去重或裁决。F1 应与 S4 的因果识别发现核对，若同源须合并，不计作多个独立缺陷。没有提出局部 PASS，因而无 PASS 反测记录；已测试同一文本内容、描述性退路及零／混合结果三项可能辩护。不提出文献缺失型 BLOCK。

## 6. 有证据支持的优点

P1 和 P4 清楚区分因果知识与描述性差异，使贡献是否兑现可被检验；这不消除 F1。

## 7. 修改优先级

1. 首先解决因果贡献的证据归属；成功标志是 S4 可核对的识别支持与 P1 的贡献表述一致。
2. 若未来发展为完整 RP，再提供最近邻研究与有边界的检索证据；成功标志是能够说明已有答案、仍未解决的部分以及本研究增加什么。此项不是本诊断摘录的必改缺陷。

## 8. 下一步

本专项不足以支持将摘录作为因果贡献已成立的材料送出；最先要解决的是 F1。整体送出建议由 S5 综合裁决。即使未来该专项通过，也仅代表所审贡献论证经受住限定范围内的检查，不代表文献穷尽、因果效应已经证实或完整申请获得认可。
